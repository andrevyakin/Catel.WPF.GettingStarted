# GettingStarted.WPF

This is the code for the getting started guide for WPF of Catel. The full guide can be found here:

https://catelproject.atlassian.net/wiki/display/CTL/Getting+started+with+WPF
